package com.Assignment.Trainer;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainerApplicationTests {

	@Test
	void contextLoads() {
	}

}
